# Sketch: an editing style made in Style Studio

1. Get the engine it runs on, once (it needs Node 22 and ffmpeg):

       git clone https://github.com/kelano86/style-studio-engine
       cd style-studio-engine
       npm install

2. Unzip this in the engine's folder, the one with package.json. It adds:

   - skills/sketch/          the Claude Code editing skill for the style
   - src/packs/sketch.json   the style pack it renders with

   The engine finds the style there by its id, so there's nothing else to set up.

3. Open Claude Code in that folder and ask it to edit your video in Sketch: the cut video in
   public/footage/<video>/, with its word timings. The engine's README has the details.

You can delete this note once that's done.
