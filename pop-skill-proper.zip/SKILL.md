---
name: pop
description: "Edit a talking-head short in Pop, a neo-brutalist sticker style, with the style-pack engine. Plans the shots, captions and joins by Pop's rules, writes a reel plan, checks it, reviews stills and renders the video. Use when asked to edit, plan or render a video in Pop, or to add Pop's graphics, captions or transitions to a talking-head edit."
---

# Pop: editing skill

Generated from `src/packs/pop.json` by `scripts/make-skill.mjs`. To change a rule, change the pack and generate
the skill again (`node scripts/make-skill.mjs pop`); don't edit these files by hand.

You edit talking-head shorts in **Pop**. A neo-brutalist sticker style: Archivo Black headlines and Space Grotesk text on lemon yellow with halftone dots, white cards with thick ink borders and hard shadows, leaning a little, the hero word on a hot-pink block, sticker icons, boxed captions, and springy arrivals with word-pop.

**How it feels.** Pop is fast and loud, and it puts its graphics on the presenter, over the footage: in its example, 51% of the running time is graphics drawn over the presenter, 26% graphics alone and 23% the presenter full frame. Something changes every 1.5 to 2.5 s. Lines snap in (12 frames each, 3 apart) and land with a bounce. Punch-ins are hard (12% over 3 frames) and come on every line. Shots meet on hard cuts, a flash in the hero colour or whip pans. Captions run 1 to 3 words, the key word on a box, and each line pops in on the spring. And it brings `word-pop` and `sticker` of its own: that's where the style's identity lives.

**What you decide.** The look is in the pack, and the engine applies it to every scene: faces, colours, grounds, cards,
the caption styling, every motion curve. You never set a colour, a font, a size or a position. You decide the edit:
which scene carries each beat and for how long, how shots join, where the punch-ins land, how the captions break, and
the video's hero colour. The rules below are Pop's for those decisions.

Run every command from the engine's root folder (the one with `package.json` and `src/packs/pop.json`).

## What you need

- **The edit**: the talking-head video, already cut (takes chosen, dead air out), as one continuous file in
  `public/footage/<video>/`. The reel is 1080x1920 at 30 fps; the edit can be landscape.
- **Word timings**: the transcript with a time for each word (an SRT, VTT or JSON from the creator, or a local Whisper
  run with word timestamps). Captions, word-pop, stickers and punch-ins are all placed on them.
- **The face, measured** in the edit's own pixels. Pull a frame with a grid on it, a line every 100 px
  (`ffmpeg -ss 5 -i public/footage/<video>/plate.mp4 -frames:v 1 -vf "drawgrid=w=100:h=100:t=2:c=red@0.6" out/face.png`),
  look at it, and read off the face's centre x, the top of the head (crown), the eye line and the chin by counting
  grid lines. They go in the plan's `shoot`, with the edit's `width` and `height` (`ffprobe` prints them).
- **How light the footage is under the face**: `node scripts/footage-tone.mjs public/footage/<video>/plate.mp4 <faceX> <eyes> <chin>`
  prints the shoot's `tone` (`{ "chest": 0.01 }` for a black shirt, near 1 for a white one). Words straight on the
  footage (word-pop, captions with no box) take white or ink from it, with an edge in the opposite tone, so they read
  on any shirt. Measure it on a frame that shows the shirt as it is for most of the video.
- **The voice**: an audio file lined up with the edit (or the edit itself, if it has sound), as the plan's `audio`.

## How you work

1. **Find the beats.** Read the transcript into beats, one point each, and name each one's kind: a hook, a payoff,
   an item, a number, a point, a proof or the end ([Pop's beats](#the-beats), below).
2. **Pick the hero colour** (below).
3. **Lay out the shots** on the edit's timeline: each beat on the scene Pop carries it with, joined the way the
   beats table says, at Pop's pace (below). Shot lengths add up to the reel, and the reel's frame n shows the edit's
   frame `from + n`. Write the plan to `plans/<video>.json` (make the folder if it isn't there; it stays out of
   git). Scenes and their props: [references/scenes.md](references/scenes.md). The plan format:
   [references/plan.md](references/plan.md). A whole video in this style: [example-plan.json](example-plan.json).
4. **Write the captions** from the word timings (below).
5. **Check the plan**: `node scripts/check-plan.mjs plans/<video>.json`. Fix every error; weigh every warning.
6. **Render stills and look at every one**: `node scripts/render-reel.mjs plans/<video>.json --stills auto` writes a
   still per shot once it has landed, plus the middle of each join, to `out/reels/<video>/`. Check each against
   [references/look.md](references/look.md):
   - Nothing collides or runs off the frame; captions clear the chin and any card.
   - Words straight on footage (word-pop, captions with no box) contrast with what is under them: white on a dark shirt, ink on a light one, each with an edge. If not, the shoot's `tone` is wrong: measure it again.
   - Headlines in Archivo Black Regular, in the case you write, set left; lead-ins in Space Grotesk Bold; labels in Space Grotesk Bold.
   - Graphic scenes on the light ground: #FFE14D and printed halftone dots growing toward a corner.
   - The hero colour shows only in the title's hero word, the list's win fact, the after number, the quote marks, the starbursts and strike-outs, the caption key word and the flash.
   - Captions: Space Grotesk Bold at 52 px, in caps, in a white box with an ink border and a hard shadow; at most one key word, and it sits on a box in the hero colour with an ink border, tilted -3°, in Archivo Black Regular.
   - The half band: the camera filling the frame below the graphics to the bottom edge, the eye line on its upper third, with a hard top edge and a 10 px rule in #111111 along it; captions ride that top edge, the whole head inside.
   - The tile: the camera in a square tile, the eye line on its upper third, with 24 px corners and a 6 px #111111 ring, the whole head inside.
   - Word-pop: the words on the chest, clear of the chin, the key word alone in the last group.
   - The stickers: each landed on its word, none over the face, the caption lane or off the frame.
   - Mid-join stills show the join (flash and whip), not a broken or empty frame.
   - Its signature shows: cards: cards with a thick ink border and a hard offset shadow, leaning -2°; the hero word and the winning number: on a filled block in the hero colour; icons: sticker icons with a white edge (the list and before/after scenes take an `icon`); arrivals: lines rise in.
   - Each still makes its beat's point on its own.

   Fix the plan and render the stills again until every one reads.
7. **Render the video**: `node scripts/render-reel.mjs plans/<video>.json` writes `out/reels/<video>.mp4`.

## Pop's rules

### The beats

| Beat | What it is | Pop carries it with | Join in |
|---|---|---|---|
| **Hook** | the first line: what the video promises | `sticker`; else `title`, `talk` in the half band or `talk` full frame | opens the video |
| **Payoff** | the line that pays the hook off: the reveal, the verdict, the twist | `word-pop`; else `talk` full frame | cut |
| **Item** | one thing in a list (a tool, a step, a mistake) with a name and a few facts | `list` | whip (`"in": "whip"`) into the first and the one that matters most; the rest cut |
| **Number** | a figure that changed or that matters: a cost, a time, a count | `sticker`; else `stat` | flash (`"in": "flash"`) into the first and the one that matters most; the rest cut |
| **Point** | a claim or a bridge in the presenter's own words | `talk` full frame | cut |
| **Proof** | someone else's words: a customer, a review, a source | `quote` | whip (`"in": "whip"`) |
| **End** | the last line: the follow, the next video, the takeaway | `talk` full frame | cut |

- Read the transcript into beats of these kinds, one point each, then give each beat Pop's first choice. Take the next one only when the first can't carry it: the words don't fit its props, it ran in the beat before (two of the same scene back to back read as one long shot), or the pace needs a change.
- A beat of a kind not in the table is a point.
- A beat whose scene is a graphic and runs past the pace gets a second shot, on a cut: the presenter (full frame) for the rest of it. `sticker` and `word-pop` land on a word: hold them about a second past that word, into the next beat, so the hit reads.
- Tag every shot with its beat (`"beat": "number"`, on each shot of the beat): check-plan then warns when a beat isn't on a scene this table gives it, comes in on a join the table doesn't give it, or never gets its join. A beat that cuts where the table gives a join is fine: that is how a join is kept to the changes that matter (see Joins).
- [example-plan.json](example-plan.json) is one video built this way, shot by shot in [references/plan.md](references/plan.md).

### Pace

- Something on screen changes every **1.5 to 2.5 s** (45 to 75 frames). A change is a new shot, a punch-in, a new word-pop group or a sticker landing; a caption changing doesn't count.
- Keep every shot longer than 0.75 s (23 frames).
- When a beat runs longer than 2.5 s, change something inside it: a punch-in, a cut to another layout, or a scene that shows the point. Never let the frame sit still past 3.1 s.
- **Punch in on every line** of full-frame talk: a punch where each new caption line starts (talk `punches`), so the frame moves with the speech. Each punch flips between wide and pushed in, 12% over 3 frames, close to a cut.
- The presenter speaks at about 175 to 215 words a minute (2.92 to 3.58 words a second). Use it to sanity-check a timing you estimate; the transcript's timings always win.
- Long form (16x9) changes every 3.5 to 5 s, but the engine renders 9x16 only for now.

### The presenter

- Layouts: **full frame** (`full`): the presenter's room filling the frame, the only layout that punches in; **the half band** (`halfBand`): the camera filling the frame below the graphics to the bottom edge, the eye line on its upper third, with a hard top edge and a 10 px rule in #111111 along it; captions ride that top edge; **the tile** (`tile`): the camera in a square tile, the eye line on its upper third, with 24 px corners and a 6 px #111111 ring.
- **Open on the half band or full frame**: the first shot is a `title` (it shows the half band) or a `talk` shot in one of those layouts.
- Full frame when the face and the delivery carry the beat; the half band or the tile when a short heading (the point, 1 to 3 words, in `head`) should hold on screen while the presenter makes it.
- The band and the tile show the camera as shot, filled edge to edge, centred on the face, and zoomed in as far as it takes to put the eye line on their upper third line: no cutouts or background removal. Over the band, captions sit on its top edge so they never cross the face; plan caption lines there short enough to read across the seam.

### Scenes

| Scene | For | Shows the presenter |
|---|---|---|
| `title` | The hook, and the start of a new section. | with a shoot: the half band |
| `talk` | Most of a video: whenever the words carry the beat and no graphic would prove the point better. | yes, in a layout you pick |
| `list` | Each item of a list video (tools, steps, mistakes), when the item has a name and two to four facts worth showing. | no |
| `stat` | A number that changed: a cost, a time, a count. The payoff of a claim. | no |
| `quote` | Someone else's words: a customer, a review, a line from a source. | no |
| `word-pop` (Pop's own) | The line that matters most in a stretch of talk: the hook's payoff, a reveal, a verdict. Its words are the captions, so the caption track hides under it. | yes: full frame |
| `sticker` (Pop's own) | A punchline, a price or a reaction you want to feel physical: the old number crossed out and the new one in a starburst, the verdict on a tag. One to three stickers, each on its word. | yes: full frame |

- **Pop's own: `word-pop`.** The line that matters most in a stretch of talk: the hook's payoff, a reveal, a verdict. Its words are the captions, so the caption track hides under it. Use it at least once a video: without it a video reads as the shared scenes in Pop's colours, not as Pop.
- **Pop's own: `sticker`.** A punchline, a price or a reaction you want to feel physical: the old number crossed out and the new one in a starburst, the verdict on a tag. One to three stickers, each on its word. Use it at least once a video: without it a video reads as the shared scenes in Pop's colours, not as Pop.
- Graphic scenes stand on the light ground (#FFE14D and printed halftone dots growing toward a corner). Set `"theme": "dark"` only to set a whole section apart (the dark ground: #141414 and printed halftone dots growing toward a corner), never shot by shot.
- Not in Pop: `slam`, `chart`, `doodle`, `command` and `float`, scene types other styles bring. The engine refuses them in Pop.
- Every scene's props, how it comes out in this style, and an example shot: [references/scenes.md](references/scenes.md).

### Joins

- **Cut** (leave `in` out) between two talk shots, inside a beat, and into the payoff, the point and the end.
- **Flash** (`"in": "flash"`: 2 frames of the hero colour over the cut) into the number. Keep it for hits, or it stops hitting.
- **Whip** (`"in": "whip"`: a whip pan: the old shot flies out to the left, smeared, as the new one flies in, over 8 frames) into the item and the proof.
- **Everything else cuts.** A join is punctuation. The flash and the whip come in on the beats above, and when one of those beats comes round again (the items of a list or a second number), only on the first and the one that matters most. Cut the rest, the way back to the presenter included: on every change a join stops meaning anything, and the video reads as a template. check-plan warns when the flash or the whip comes in more than 3 times a video, or when one join comes in on three shots in a row.
- Never ease (`ease`), zoom-through (`zoom`), wipe (`wipe`), blur (`blur`) or glitch (`glitch`): Pop has them off, and the engine refuses them.
- Whip keeps the shot before on screen under the new one for its frames; the reel's length doesn't change. The shot before must be longer than the join.

### Captions

- Captions are a track on the reel's timeline (`captions`), placed on the word timings: **1 to 3 words a line**, a new line at every stress, so the words keep pace with the voice. Back to back and never overlapping; a gap only where the presenter pauses.
- Mark at most one **key word** a line with asterisks (`"text": "five mods that feel *illegal*"`): it sits on a box in the hero colour with an ink border, tilted -3°, in Archivo Black Regular. Not every line needs one: the stressed word, the number, the turn.
- Write them as spoken, in normal case: the pack sets them in caps.
- Captions hide under `quote` and `word-pop`: those show their own words. Leave captions out over word-pop; its groups are the captions there.
- You never style or animate them; the pack does: Space Grotesk Bold at 52 px, in caps, in a white box with an ink border and a hard shadow, and each line pops in on the spring as it comes on.

### Hero colour

- **One hero colour per video**, from Pop's rotation, in order: win (#FF4D8D), blue (#2F6BFF), green (#00C26E) and orange (#FF7A1A). Never the last video's: take the next one after it. `check-plan` finds the newest other plan for Pop in the same folder and warns on a match, so keep a creator's plans together in `plans/`.
- It colours the title's hero word, the list's win fact, the after number, the quote marks, the starbursts and strike-outs, the caption key word and the flash. You never pick a colour for anything else.
- The caption key word is always #111111, whatever the hero colour.

### The end

- **Hold the end**: the last shot can run up to 1.5 s (45 frames) past the last word, then the video ends.

## Rendering

- **A reel**: `node scripts/render-reel.mjs plans/<video>.json`, or `--stills auto` / `--stills 0,45,90` for
  frames. The reel entry is `src/reel/entry.tsx` (composition `Reel`) and the plan is its input props, so the plan's
  `pack` and `hero` pick the pack and the colour.
  `npx remotion render src/reel/entry.tsx Reel out/<video>.mp4 --props=plans/<video>.json` works too, but on Windows
  it leaves Remotion's temp copies of the footage behind; the script removes them.
- **Scrub it in the Studio**: `npx remotion studio src/reel/entry.tsx --props=plans/<video>.json`.
- **The board** shows the style itself, its scenes with fixed words:
  `node scripts/render-stills.mjs --packs pop --scenes Title,List,Stat,Quote,WordPop,Sticker` (stills in `out/stills/pop/`), or one
  still: `npx remotion still src/board/entry.tsx Board-Title out/title.png --frame=60 --props="{\"pack\":\"pop\",\"hero\":\"blue\"}"`.
  The board entry is `src/board/entry.tsx` (`npm run studio`).
- The engine refuses a plan it can't render before drawing a frame, and says why, by shot: a scene Pop doesn't bring,
  a missing or unknown prop, a join or a layout Pop has off.
- `BROWSER=<path to chrome-headless-shell>` reuses a browser already on disk.
- The example plan renders with the engine's demo footage, if it's on this machine:
  `node scripts/render-reel.mjs skills/pop/example-plan.json --stills auto`.
